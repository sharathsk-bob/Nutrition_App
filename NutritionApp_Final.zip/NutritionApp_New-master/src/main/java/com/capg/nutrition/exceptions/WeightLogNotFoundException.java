package com.capg.nutrition.exceptions;

public class WeightLogNotFoundException extends Exception {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public WeightLogNotFoundException(String message) {
        super(message);
	}

}