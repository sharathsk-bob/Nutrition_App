package com.capg.nutrition;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NutritionAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
